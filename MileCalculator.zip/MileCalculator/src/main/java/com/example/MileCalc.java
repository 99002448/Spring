package com.example;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.ApplicationContext;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.example.training.VehicleDetails;

@SpringBootApplication
public class MileCalc implements CommandLineRunner {
	public static void main(String[] args) {
		SpringApplication.run(MileCalc.class, args);
	}

	@Autowired
	ApplicationContext context;

	@Override
	public void run(String... args) throws Exception {
		VehicleDetails vehicleDetails = context.getBean(VehicleDetails.class);
		vehicleDetails.getMileage("bike");
		vehicleDetails.getMileage("car");
		// TODO Auto-generated method stub

	}

}
