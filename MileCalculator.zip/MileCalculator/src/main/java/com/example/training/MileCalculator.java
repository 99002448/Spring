package com.example.training;

public interface MileCalculator {

		void showMileage();
}
