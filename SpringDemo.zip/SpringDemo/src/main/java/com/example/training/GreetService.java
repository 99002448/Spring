package com.example.training;

public interface GreetService {
	String greet(String name);

}
