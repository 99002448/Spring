package com.lts.autowiring;

public interface Shape {

	void calculateArea(int x, int y);
}