function $(id){
	return document.getElementById(id);
}
