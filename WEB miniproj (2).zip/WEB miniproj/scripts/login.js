function validate(){
var username = $("username").value;
var password = $("password").value;
var err=$("error").innerHTML;
//empty field validation
if(username==""){alert("User Name Should not be empty");} if(password==""){alert("Password should not be empty");}
//if name and password match
if ( username == "negative" && password == "naseeb"){
$("error").innerHTML="Log in sucessfull";
window.location = "brands.html";
return false;
}
//code for try upto 3 chance then disable username and password field
else{
$("error").innerHTML="<br>Incrorrect username and password"+"<br>You have left"+maxTry+" attempt.";
}
}